Please download the Project-5 (Secure Authorship Attribution System) with all it contents and run the main.py file as follows.




(1) -- > Please note that the program will run only when you have the 'AdversarialTest.txt' and AdversarialTestResults.txt files in the project repository.


(2) -- > Please put the advTextxx.txt files in the 'textFiles' directory.

(3) -- > Run the main.py
         $ python main.py



For questions plz write to 

janzaib@auburn.edu
